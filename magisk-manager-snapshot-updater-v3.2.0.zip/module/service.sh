#!/system/bin/sh

MODDIR=${0%/*}

sh $MODDIR/updater.sh &
